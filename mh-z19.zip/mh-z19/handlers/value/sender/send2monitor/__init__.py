import send2monitor

def handle(data_source_name, data_name, value):
	send2monitor.handle(data_source_name, data_name, value) 
