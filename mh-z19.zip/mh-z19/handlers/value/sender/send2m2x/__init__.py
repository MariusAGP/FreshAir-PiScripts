import send2m2x

def handle(data_source_name, data_name, value):
	send2m2x.handle(data_source_name, data_name, value)  
