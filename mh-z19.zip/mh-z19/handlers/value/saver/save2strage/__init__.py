import save2strage

def handle(data_source_name, data_name, value):
	save2strage.handle(data_source_name, data_name, value)  
