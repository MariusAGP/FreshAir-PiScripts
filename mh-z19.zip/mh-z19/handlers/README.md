# handlers
sample handlers of [PondSlider](https://github.com/UedaTakeyuki/pondslider)

## folder
- [sensor](https://github.com/UedaTakeyuki/handlers/tree/master/sensor): Sample sensor handlers
- [value](https://github.com/UedaTakeyuki/handlers/tree/master/value): Sample value handlers
